var width_tests = {
    "iphone5": 320,
    "iphone6": 375,
    "iphone6-plus": 414,
    "ipad": 768,
    "desktop": 1024
};

module.exports = {
    "port": 3000,
    "width-tests": width_tests
}